function NoPage() {
  return (
    <>
      <h1>Page Not Found</h1>
    </>
  );
}

export default NoPage;

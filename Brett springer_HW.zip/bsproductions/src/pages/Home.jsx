import "../../styles/App.css";
import { useState } from "react";

import About from "../components/About";
import Research from "../components/Research";
import Personas1 from "../components/Personas1";
import Scenario1 from "../components/Scenario1";
import Scenario2 from "../components/Scenario2";
import Personas2 from "../components/Personas2";
import Storyboard from "../components/Storyboard";
import Moodboard from "../components/Moodboard";
import Flowchart from "../components/Flowchart";
import Wireframes from "../components/Wireframes";
import GUI from "../components/GUI";
import Prototype from "../components/Prototype";
import References from "../components/References";

function Home() {
  const [homeState, setHomeState] = useState(<About />);

  const setAbout = () => {
    setHomeState(<About />);
  };
  const setResearch = () => {
    setHomeState(<Research />);
  };
  const setPersonas1 = () => {
    setHomeState(<Personas1 />);
  };
  const setScenario1 = () => {
    setHomeState(<Scenario1 />);
  };
  const setScenario2 = () => {
    setHomeState(<Scenario2 />);
  };
  const setPersonas2 = () => {
    setHomeState(<Personas2 />);
  };
  const setStoryboard = () => {
    setHomeState(<Storyboard />);
  };
  const setMoodboard = () => {
    setHomeState(<Moodboard />);
  };
  const setFlowchart = () => {
    setHomeState(<Flowchart />);
  };
  const setWireframes = () => {
    setHomeState(<Wireframes />);
  };
  const setGUI = () => {
    setHomeState(<GUI />);
  };
  const setPrototype = () => {
    setHomeState(<Prototype />);
  };
  const setReferences = () => {
    setHomeState(<References />);
  };

  return (
    <>
      <div className="home-container">
        <img className="home-logo" src="../Logo.jpg" />

        <div className="button-container">
          <button className="button" onClick={setAbout}>
            About
          </button>
          <button className="button" onClick={setResearch}>
            Research
          </button>
          <button className="button" onClick={setPersonas1}>
            Personas1
          </button>
          <button className="button" onClick={setPersonas2}>
            Personas2
          </button>
          <button className="button" onClick={setScenario1}>
            Scenario1
          </button>
          <button className="button" onClick={setScenario2}>
            Scenario2
          </button>
          <button className="button" onClick={setStoryboard}>
            Storyboard
          </button>
          <button className="button" onClick={setMoodboard}>
            Moodboard
          </button>          
          <button className="button" onClick={setFlowchart}>
            Flowchart
          </button>
          <button className="button" onClick={setWireframes}>
            Wireframes
          </button>
          <button className="button" onClick={setGUI}>
            GUI
          </button>
          <button className="button" onClick={setPrototype}>
          Prototype
          </button>
          <button className="button" onClick={setReferences}>
            References
          </button>
        </div>

        <div className="anime-container">{homeState}</div>
      </div>
    </>
  );
}

export default Home;

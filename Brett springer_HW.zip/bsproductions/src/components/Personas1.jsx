import React from "react";
import { useState, useEffect } from "react";
import "../../styles/App.css";

function Personas1() {
  return (
    <>
      <h1>Personas 1</h1>
      <p>
        <img className="persona-image" src="/persona1.jpg" alt="Persona 1" />
      </p>
    </>
  );
}

export default Personas1;
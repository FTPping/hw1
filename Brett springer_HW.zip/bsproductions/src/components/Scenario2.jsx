import React from "react";
import { useState, useEffect } from "react";
import "../../styles/App.css";

function Scenario2() {
  return (
    <>
      <h1>Scenario 2</h1>
      <p>
        <img className="Scenario2" src="/Scenario2.jpg" alt="Scenario 2" />
      </p>
    </>
  );
}

export default Scenario2;

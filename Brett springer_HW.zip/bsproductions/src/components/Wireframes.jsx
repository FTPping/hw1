import React from "react";
import { useState, useEffect } from "react";
import "../../styles/App.css";

function Wireframes() {
  return (
    <>
    <h1> Wireframe</h1>
    <p>
      <img className="Wireframes" src="/wireframe 1.jpg" alt="Wireframe" />
      </p>
      <p>
      <img className="Wireframes2" src="/Wireframe 2.jpg" alt="Wireframe2" />
      </p>
  </>
  );
}
  export default Wireframes;
import React from "react";
import { useState, useEffect } from "react";
import "../../styles/App.css";

function References() {
  return (
    <>
      <h1>References</h1>
      <p>
        Citations and references used in the project research and design process. <br />
        Pictures: <br />
        https://kenoshanews.com/news/local/jane-doe-identified-woman-arrested-for-years-of-abuse/article_259c079d-1b0d-5b22-8176-5c1ffe07c4a2.html <br />
        https://www.wallofcelebrities.com/celebrity/john-doe/pictures/john-doe_862803.html <br />
        https://livethegoodlifewithsara.com/being-organized/ <br />
        https://medium.datadriveninvestor.com/how-to-make-a-website-with-javascript-html-and-css-781cd037c074 <br />
        https://www.dluxeprints.co.uk/products/2024-grey-calendar-poster <br />
        https://www.timedoctor.com/blog/task-list-template/ <br />
        https://www.thethreetomatoes.com/organize-your-home-with-these-101-hacks-part-2-bed-bath-and-beyond <br />
        https://teamrxc.com/post/task-management-and-its-impact-on-your-business/ <br />
        https://ar.inspiredpencil.com/pictures-2023/unorganized-office-before-and-after <br />
        https://www.dreamstime.com/stock-photo-woman-closing-opening-her-laptop-office-image57358474 <br />
        https://www.notion.so/templates/notion-student-dashboard-3 <br />
        https://docs.gitlab.com/ee/user/project/issues/due_dates.html <br />
        https://www.proofhub.com/articles/critical-path-method <br />
        https://www.apfelbaum-consultants.de/blog/agiler-fuehren-2-das-kanban-board/kanban-desk-or-board-with-colorful-stickers-to-do-doing-done-kanban-concept-scrum/ <br />
        https://www.dreamstime.com/stock-photo-computer-alert-warning-concept-illustration-design-graphic-image77282298 <br />
        https://www.dreamstime.com/head-shot-young-happy-grateful-girl-feeling-relief-head-shot-portrait-young-happy-grateful-girl-holding-folded-hands-chest-near-image170082010
      </p>
    </>
  );
}

export default References;
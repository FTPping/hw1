import React from "react";
import { useState, useEffect } from "react";
import "../../styles/App.css";

function Prototype() {
  return (
    <>
      <h1>Prototype</h1>
      <p>Link to the prototype or a recorded screen demo of the system.</p>
    </>
  );
}

export default Prototype;

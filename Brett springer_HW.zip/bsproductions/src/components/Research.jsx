import React from "react";
import { useState, useEffect } from "react";
import "../../styles/App.css";

function Research() {
  return (
    <>
      <h1>Research</h1>
      <p>
        This project focuses on designing a user-centered UI prototype using a
        rapid prototyping development model.
      </p>
    </>
  );
}

export default Research;

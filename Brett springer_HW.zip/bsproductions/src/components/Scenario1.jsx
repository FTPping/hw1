import React from "react";
import { useState, useEffect } from "react";
import "../../styles/App.css";

function Scenario1() {
return (
 <>
    <h1> Scenario 1</h1>
    <p>
      <img className="Scenario1" src="/Scenario1.jpg" alt="Scenario 1" />
    </p>
  </>
  );
}

export default Scenario1;

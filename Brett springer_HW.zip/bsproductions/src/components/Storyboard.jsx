import React from "react";
import { useState, useEffect } from "react";
import "../../styles/App.css";

function Storyboard() {
return (
 <>
    <h1> Storyboard</h1>
    <p>
      <img className="Storyboard" src="/Storyboard.jpg" alt="Storyboard" />
    </p>
  </>
  );
}

export default Storyboard;
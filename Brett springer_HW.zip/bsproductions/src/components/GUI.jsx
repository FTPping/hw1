import React from "react";
import { useState, useEffect } from "react";
import "../../styles/App.css";

function GUI() {
  return (
    <>
      <h1>GUI</h1>
      <p>Graphical user interface designs for the project.</p>
    </>
  );
}

export default GUI;

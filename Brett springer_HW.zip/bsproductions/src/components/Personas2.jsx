import React from "react";
import { useState, useEffect } from "react";
import "../../styles/App.css";

function Persona2() {
  return (
    <>
       <h1> Persona 2</h1>
       <p>
         <img className="persona-image" src="/Persona2.jpg" alt="Persoana 2" />
       </p>
     </>
    );
  }
  export default Persona2;
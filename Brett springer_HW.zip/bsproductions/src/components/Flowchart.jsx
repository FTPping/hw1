import React from "react";
import { useState, useEffect } from "react";
import "../../styles/App.css";

function Flowchart() {
  return (
    <>
       <h1> Flowchart</h1>
       <p>
         <img className="Flowchart" src="/class diagram.png" alt="Flowchart" />
       </p>
     </>
     );
   }
   

export default Flowchart;

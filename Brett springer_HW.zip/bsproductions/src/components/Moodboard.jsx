import React from "react";
import { useState, useEffect } from "react";
import "../../styles/App.css";

function Moodboard() {
return (
 <>
    <h1> Moodboard</h1>
    <p>
      <img className="Moodboard" src="/Moodboard.png" alt="Moodboard" />
    </p>
  </>
  );
}

export default Moodboard;
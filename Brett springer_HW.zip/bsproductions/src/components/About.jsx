import React from "react";
import { useState, useEffect } from "react";
import "../../styles/App.css";

function About() {
  return (
    <>
      <h1>About</h1>
      <p>
      Welcome to my Human Computer Interaction project developed under BS Production. This project is centered around designing a user-centered UI prototype using a rapid prototyping model. My goal is to create an engaging and intuitive interface that meets the needs of the target audience by understanding their goals, behaviors, and motivations.
      The project focuses on a mobile/web application that will be iteratively developed, starting from user research and persona creation to prototyping and evaluation. Each step is designed to ensure that the UI prototype provides the best possible user experience, integrating feedback and insights gained along the way.
      I am a student from Florida International University, managing all aspects of the project myself. With a strong focus on user-centered design principles, I aim to create an effective and intuitive digital solution that is both functional and engaging.
      </p>
    </>
  );
}

export default About;
